import React, { useState } from 'react'
import { Search } from 'lucide-react'
import { dummyConnectionsData } from '@assets/assets'
import { UserCards } from '@components/Cards';
import { Loading } from '@components/Loading'

export const Connect = () => {

    const [input, setInput] = useState(String)

    const [users, setUsers] = useState(dummyConnectionsData)

    const [loading, setLoading] = useState(false)


    const searchHandle = async (event) => {
      if (event.key === ('Enter')) {
        setUsers(Array())
        setLoading(true)
        setTimeout(() => {
          setUsers(dummyConnectionsData)
          setLoading(false)
        }, 1000)
      } //end if
    } //end function

    return (<React.Fragment>
              <div className={'min-h-screen bg-gradient-to-b from-slate-50 to-white'}>
                <div className={'max-w-6xl mx-auto p-6'}>
                  {/* Title */}
                  <div className={'mb-8'}>
                    <h1 className={'text-3xl font-bold text-slate-900 mb-2'}>Discover People</h1>
                    <p className={'text-slate-600'}>Grow your connections</p>
                  </div>

                  {/* Search */}
                  <div className={'mb-8 shadow-md rounded-md border border-slate-200/60 bg-white/80'}>
                    <div className={'p-6'}>
                      <div className={'relative'}>
                        <Search className={'absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5'} />
                        <input type={'text'} value={(input)} onChange={((event) => (setInput(event.target.value)))} placeholder={'Search people by name, username, bio or location...'} className={'pl-10 sm:pl-12 py-2 w-full border border-gray-300 rounded-md max-sm:text-sm'} />
                      </div>
                    </div>
                  </div>
                  {/* Users */}
                  <div className={'flex flex-wrap gap-6'}>
                    {users.map((user) => (<UserCards user={(user)} key={(user._id)} />))}
                  </div>
                  {(loading && (<Loading height={'60vh'} />))}
                </div>
              </div>
           </React.Fragment>)
}

